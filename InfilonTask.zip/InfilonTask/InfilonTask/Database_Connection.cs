﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Data;

namespace InfilonTask
{
    public class Database_Connection
    {
        SqlConnection con = new SqlConnection();
        public void OpenConnection()
        {
            string connetionString;
            //SqlConnection con;
            connetionString = @"Data Source=LAPTOP-71DEV3C5\SQLEXPRESS;Initial Catalog=Subham;User ID=Subham;Password=1234";
            con = new SqlConnection(connetionString);

            con.Open();
        }
        public DataTable SQLDataAdapter(String query)
        {
            try
            {
                Console.WriteLine(query);
                //sql data adapter
                if (con.State == ConnectionState.Closed)
                {
                    OpenConnection();  //open connection
                }
                SqlDataAdapter sda = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                return dt;
            }
            catch (ThreadAbortException ex)
            {
                Console.WriteLine("Exception: " + ex);
                DataTable dt = new DataTable();
                return dt;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex);
                DataTable dt = new DataTable();
                return dt;
            }
        }
        public int SaveLogo(String UserName, String str, byte[] img)
        {
            if (con.State == ConnectionState.Closed)
            {
                OpenConnection();
            }
            SqlCommand cmd = new SqlCommand("INSERT INTO ChatAPT (PublishTo,ReceivedFrom,File_Data,Date_Time) VALUES ('" + UserName + "','" + str.ToString() + "', @logo , CURRENT_TIMESTAMP+0.2291667) select @@Identity as Iden ", con);
            cmd.Parameters.AddWithValue("@logo", img);

            var x = cmd.ExecuteScalar();

            return Convert.ToInt32(x);
        }
        public int SQLCommand_ExecuteNonQuery(String query)
        {
            try
            {
                Console.WriteLine(query);
                //sql command 
                if (con.State == ConnectionState.Closed)
                {
                    OpenConnection();  //open connection
                }
                SqlCommand cmd = new SqlCommand(query, con);
                return cmd.ExecuteNonQuery();

            }
            catch (ThreadAbortException ex)
            {
                Console.WriteLine("Exception: " + ex);
                return 0;

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex);
                return 0;
            }
        }


        public String SQLCommand_ExecuteScalar(String query)
        {

            try
            {
                Console.WriteLine(query);
                //sql command
                if (con.State == ConnectionState.Closed)
                {
                    OpenConnection();  //open connection
                }
                SqlCommand cmd = new SqlCommand(query, con);
                String temp = cmd.ExecuteScalar() + "";
                return temp.Trim();
            }
            catch (ThreadAbortException ex)
            {
                //  WriteToExFile(ex + "");
                return (ex + "");
            }
            catch (Exception ex)
            {
                //RadMessageBox.Show(ex.Message + "\n\n" + query, "Athena Enterprise Planning", MessageBoxButtons.OK, RadMessageIcon.Error);
                // WriteToExFile(ex + "\n\n" + query);
                return ex + "";
            }
        }
    }
}
