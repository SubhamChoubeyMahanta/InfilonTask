using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Data;
using System.Net;
using System.Numerics;
using System.Xml.Linq;

namespace InfilonTask.Pages
{
    public class LoginModel : PageModel
    {
        //Database_Connection dc = new Database_Connection();
        public bool Result = false;

        public void OnGet()
        {
        }

        public void OnPost()
        {
            string Username = Request.Form["Username"];
            string Password = Request.Form["Password"];

            if (Username.Length == 0 || Password.Length == 0)
            {
                return;
            }

            try
            {
                //dc.OpenConnection();
                //int i = dc.SQLCommand_ExecuteNonQuery("Select count(*) from USER_LOGIN where V_USERNAME = '" + Username + "' and Passwd = '" + Password + "'");
                if (Username!="Infilon" && Password!="1234")
                {
                    Result = false;
                }
                else
                {
                    Result = true;
                    Response.Redirect("/Student/Index");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.Message);
            }
        }
    }
}
