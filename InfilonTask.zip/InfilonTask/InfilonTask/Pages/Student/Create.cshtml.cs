using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
//using StackExchange.Redis;
using System.Net.Security;
using System.Data.SqlClient;
using System.Data;

namespace InfilonTask.Pages.Student
{
    public class CreateModel : PageModel
    {
        Database_Connection dc = new Database_Connection();
        public string Name = "", Class = "";
        public string errorMessage = "";
        public string successMessage = "";

        public void OnGet()
        {

        }

        public void OnPost() 
        {
            Name = Request.Form["Name"];
            Class = Request.Form["Class"];

            if(Name.Length == 0 || Class.Length == 0)
            {
                errorMessage = "All the fields are required";
                return;
            }

            //save the new client into the database
            try
            {
                dc.OpenConnection();
                dc.SQLDataAdapter("Insert INTO StudentTable values('"+ Name +"','"+ Class +"','','')");
            }
            catch(Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }

            Name = Class = "";
            successMessage = "New Student Added Correctly";

            Response.Redirect("/Student/Index");
        }
    }
}
