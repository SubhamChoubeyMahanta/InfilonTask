using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Data;

namespace InfilonTask.Pages.Student
{
    public class EditModel : PageModel
    {
        Database_Connection dc = new Database_Connection();
        public string Id = "", Name = "", Class = "";
        public string errorMessage = "";
        public string successMessage = "";

        public void OnGet()
        {
            Id = Request.Query["ID"];

            try
            {
                dc.OpenConnection();
                DataTable dt = dc.SQLDataAdapter("Select * from StudentTable where ID = '" + Id+"'");

                Id = dt.Rows[0]["ID"].ToString();
                Name = dt.Rows[0]["Student"].ToString();
                Class = dt.Rows[0]["Class"].ToString();
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }
        }

        public void OnPost() 
        {
            Id = Request.Form["ID"];
            Name = Request.Form["Name"];
            Class = Request.Form["Class"];

            if (Id.Length == 0 || Name.Length == 0 || Class.Length == 0)
            {
                errorMessage = "All the fields are required";
                return;
            }

            try
            {
                dc.OpenConnection();
                dc.SQLDataAdapter("Update StudentTable Set Student = '" + Name + "', Class = '" + Class + "' where ID = '" + Id + "'");
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }

            Name = Class = "";
            successMessage = "Update Student Correctly";

            Response.Redirect("/Student/Index");
        }
    }
}
