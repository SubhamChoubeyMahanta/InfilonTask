using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data;
using System.Data.SqlClient;

namespace InfilonTask.Pages.Student
{
    public class IndexModel : PageModel
    {
        Database_Connection dc = new Database_Connection();
        public DataTable dt = new DataTable();

        public void OnGet()
        {
            try
            {
                dc.OpenConnection();
                dt = dc.SQLDataAdapter("Select * from StudentTable order by Id");
            }
            catch(Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }
        }
    }
}
